﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PR3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char[,] alfeng = {     {'A', 'B', 'C', 'D', 'E'},
                                   {'F', 'G', 'H', 'I', 'K'},
                                   {'L', 'M', 'N', 'O', 'P'},
                                   {'Q', 'R', 'S', 'T', 'U'},
                                   {'V', 'W', 'X', 'Y', 'Z'}
                               };


            Console.WriteLine("Введите сообщение рускими буквами для шифровки: ");
            string message = Console.ReadLine();
            string new_message = "";

            string path = @"Input.txt";
            StreamWriter sw = new StreamWriter(path, false);
            sw.WriteLine(message);
            sw.Close();

            for (int i = 0; i < message.Length; i++)
            {
                for (int j = 0; j < alfeng.GetLength(0); j++)
                    for (int k = 0; k < alfeng.GetLength(1); k++)
                        if (Char.ToLower(alfeng[j, k]) == message[i] || Char.ToUpper(alfeng[j, k]) == message[i])
                        {
                            new_message += (Convert.ToString(j) + Convert.ToString(k));
                            break;
                        }

            }
            string path1 = @"Result.txt";

            StreamWriter sw1 = new StreamWriter(path1, false);

            sw1.WriteLine(new_message);

            sw1.Close();

            Console.WriteLine("Подсчет и запись выполнены и занесены в файл Result.txt!");
            Console.WriteLine(new_message);
            Console.ReadKey();
        }
    }
}
